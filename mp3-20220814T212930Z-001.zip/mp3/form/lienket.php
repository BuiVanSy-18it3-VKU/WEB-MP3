<div class="link-group">
				<p class="link-group-title">
                	<img src="image/giaodien/icon-foo.png" alt="">Online Mp3
              	</p>
				<ul>
					<li><a href="index.php" title="Music">Music</a></li>
					<li><a href="index.php" title="Music">NonStop DJ</a></li>
				</ul>
			</div><!--End .link-group -->				
			<div class="link-group">
				<p class="link-group-title"><img src="image/giaodien/Icon_cai.png" alt=""> Cài đặt</p>
					<li><a href="?mod=suathongtin" title="Thông tin">Thông tin cá nhân</a></li>
					<li><a target="_blank" href="trinhduyet.html" title="File Fox">Trình duyệt của bạn</a></li>
			</div><!--End .link-group -->
				<div class="link-group">
					<p class="link-group-title"><img src="image/giaodien/icon-mor.png" alt=""> Clip+</p>
						<li><a href="#" title="Clip">Clip</a></li>
						<li><a href="#" title="Clip">Clip Phim</a></li>
				</div><!--End .link-group -->
                <div class="link-group">
                    <p class="link-group-title"><img src="image/giaodien/icon-phi.png" alt=""> Xem Phim</p>
						<li><a href="#" title="Phim">Xem Phim</a></li>
						<li><a href="#" title="Phim">Phim</a></li>
                </div><!--End .link-group -->
                <div class="link-group">
                    <p class="link-group-title"><img src="image/giaodien/icon-lie.png" alt=""> Liên hệ</p>
					<div class="cont">
						<div><img src="image/giaodien/phone000.png" alt=""> <strong>0122-710-0449</strong>
                        </div>
						<div><a href="mailto:phatvalong@gmail.com"><img src="image/giaodien/mail0000.png" alt="">phatvalong@gmail.com</a>
                        </div>
						<div><a href="ymsgr:sendIM?phatvalong"><img src="image/giaodien/smile000.png" alt="">Phát™</a>
                        </div>
					</div>
                </div><!--End .link-group -->
				<div class="link-group">
					<div class="logo"><!--<img src="image/giaodien/logo10000.png" alt="Online">-->
                    </div>
                </div><!--End .link-group -->
                <div class="clr">
                </div>
            </div>
            <div class="clr">
            </div>
            
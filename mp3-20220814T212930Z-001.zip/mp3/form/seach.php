<div class="search_new">
	<div class="search_new_mid">
		<form action="./?mod=timkiem" method="post">
		<input class="tbsearch" type="text" name="key" onclick="this.select()" onmouseover="this.focus()" onkeyup="M.sea(this.value)" maxlength="255" placeholder="Tên bài hát ">
		<input type="submit" value="" id="btn_search" name="nuttim">
		</form>
	</div>
</div>
<div class="tab">
    <li class="tab_selected"><a title="VKU"> VKU | Sỹ</a></li>
</div>
<?php 
$dbhost ="localhost";
$dbuser="root";
$dbpass ="";
$db="mp3";
$conn = mysqli_connect("$dbhost","$dbuser","$dbpass") or die('Khong the ket noi' . mysql_error());
mysqli_select_db($conn, "mp3");
mysqli_query("SET NAMES 'UTF8'");
?>
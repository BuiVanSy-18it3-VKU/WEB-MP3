<div class="header_in_out">
	<ul class="header_in_out_logged">
		<li ><a onclick="Login_Box();">Ðăng nhập</a></li>
		<li class="li-last-child"><a href="dangki.php">Ðăng ký</a></li>
	<div class="clear">
	</div>
	</ul> 
</div>

<?php
if(!isset($_SESSION['idadmin']))
	{	
		//header('refresh: 0; url=index.php');
		//echo '<script type="text/javascript"> alert("Hay Dang Nhap De Su Dung Chuc Nang Nay");</script>';
		//header('location:index.php');
	}
	
?>
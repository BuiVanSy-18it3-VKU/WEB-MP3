<div id="m_1">
			<?php include "form/chude.php";?>  <!--form chủ đề bên trái-->     
        </div>
        <!--2-->
        <div id="m_2">			
            <div class="box2 w_2">
            	<?php include"form/baihatmoi.php";?>      <!--form bài hát mới-->  
         	</div>
        <!--3-->
        <div id="m_3">
			<?php include"form/baihathot.php";?><!--form bài hát hot do admin đưa ra-->
		</div>		        			
        <div class="box3 w_3">
			<?php include"form/BXHnhac.php";?><!--form BXH nhạc-->
		</div>
		
		<div class="box w_3">
        	<?php include"form/thongke.php"; ?><!--form thống kê số lượng đang ol-->
        </div>
        <div class="clr">
        </div>